#=========================================================
# XML Sitemap Generator - OpenCart
# Readme
#=========================================================


CONTENTS OF THIS FILE
---------------------

 * SUPPORTED OPENCART VERSIONS
 * OVERVIEW
 * EXTENSION FEATURES LIST
 * SYSTEM REQUIREMENTS
 * INSTALLATION
 * UPGRADE
 * TROUBLESHOOTING
 * CHANGELOG
 * LIVE DEMO
 * SUPPORT
 * LICENSE
 * COPYRIGHT



SUPPORTED OPENCART VERSIONS
---------------------------
 
All 3.0.x.x versions 
All 2.2.x.x, and 2.3.0.x versions 

As of February 13, 2018



OVERVIEW
--------

This OpenCart extension helps you to create XML sitemaps fully compliant with all 
Google requirements without any effort, which lets you improve the crawlability 
of your stores, and make search engines better understand your products and website. 
The better understanding the search engines have of your content, the more confident 
they are showing it to their searchers. Cuispi XML Sitemap Generator supports an 
unlimited number of XML sitemaps for products, categories, manufacturers, information, 
and custom page links. This extension has been tested on over 1 million (1,000,000) 
items via both web browser and the command line. 



EXTENSION FEATURES LIST 
-----------------------

XML Sitemap Generator includes a number of features and benefits, perfect for 
your online store. Using this OpenCart extension, you can efficiently:

* Create an unlimited number of XML sitemaps for products, categories, manufacturers, 
  information, and custom page links. This extension has been tested on over 1 
  million (1,000,000) items via both web browser and the command line
* Create advanced XML sitemaps fully compliant with all Google requirements. XML 
  Sitemap Generator is capable of splitting sitemap contents into multiple XML 
  Sitemap files and creating XML Sitemap index files. Accordingly, no matter how 
  many pages your store may have, your XML sitemaps will always be in line with 
  Google’s guidelines—which require that all formats limit a single sitemap to 
  50MB (uncompressed) and 50,000 URLs
* Keep all your sitemaps organized in a hierarchical (tree-based) structure
* Create the sitemaps that include product URLs in all languages from all your 
  stores (multi-stores) that you want to cover
* Create the sitemaps that include category/subcategory URLs and the product URLs 
  belonging to them in all languages from all your stores (multi-stores) that you 
  want to cover
* Create the sitemaps that include manufacturer URLs and the product URLs belonging 
  to them in all languages from all your stores (multi-stores) that you want to cover
* Create the sitemaps that include information URLs in all languages from all your 
  stores (multi-stores) that you want to cover
* Create the sitemaps that include any other page URLs from all your stores 
  (multi-stores) that you want to cover
* Even create sitemaps that include a large number of URLs (tens of thousands, 
  hundreds of thousands of URLs, or even more)
* Set <changefreq>, <priority>, and a maximum number of URLs generated in a single sitemap
* Add hreflang for language and regional URLs to product, category, manufacturer, 
  and information sitemaps
* Use XSL stylesheets to make your sitemaps and sitemap indexes human readable
* Set a custom width and height to the images in XML sitemap files
* Automate the process of generating sitemaps with your command-line interface 
  (CLI) and a cron job/Windows Task Scheduler job.
* Please note that this extension provides only PHP methods to be executed via CLI. 
  At the time of writing (December 2017), since OpenCart lacks a feature of executing 
  PHP code through the command line by default, it is required to add CLI support 
  to your OpenCart in order to run the PHP methods provided by the XML Sitemap 
  Generator extension. If you don't have any CLI functionality added to your OpenCart 
  yet, we recommend that you use iSenseLabs' oc_cli extension (OpenCart 2.2.x-2.3.x 
  compatible, as of December 2017) available at https://github.com/iSenseLabs/oc_cli. 
  Also the OpenCart 3.0.x compatible version is available at https://github.com/cuispi/oc_cli_mod
* Ensure data consistency and accuracy using file locking, allowing only one 
  process to generate XML sitemaps it in a specific time
* Optionally change the default location of the sitemap folder (catalog/view/sitemap) 
  to any location you like within your OpenCart installation
* Use this extension together with Multilingual SEO Toolkit (version 4.0.0 or later)
* Create your own admin language files by copying and translating the original ones. 
  Defaults to English (en-gb/english)
* Install and setup this extension quickly and easily


  
SYSTEM REQUIREMENTS
-------------------

This guide covers detailed system requirements for a XML Sitemap Generator installation.

* PHP 5.3.x or later
* MySQL 5.1.x or later

Note that if you want to create a large number of URLs (tens of thousands, hundreds of 
thousands of URLs, or even more) in a single process, the following must be taken 
into consideration:

* The max_execution_time in your php.ini must be changeable through the ini_set() function.
* In PHP 5.3.x, the Safe Mode must be turned off.
* The max_execution_time becomes effective only when running a script from a web 
  server (e.g., via web browser). When running the script from the command line 
  or a cron job, the default setting is 0 (unlimited).
* Your web server can have other timeout configurations that may also interrupt 
  PHP execution. Apache has a Timeout directive and IIS has a CGI timeout function. 
  Both default to 300 seconds. See your web server documentation or ask your web 
  hosting company for specific details.



INSTALLATION
------------

See INSTALL.txt



UPGRADE
-------

See UPGRADE.txt



TROUBLESHOOTING
-----------------

See TROUBLESHOOTING.txt



CHANGELOG
-----------------

See CHANGELOG.txt



LIVE DEMO
---------

Try out the demo at:
http://opencart.cuispi.com/demos/xml_sitemap_generator/



SUPPORT
-------

Cuispi Priority Support is a priority response support channel that is staffed 
with our friendly and experienced Technical Support team. Priority Support is 
automatically included in your initial purchase price for a period of one year. 

If your license is already expired and you choose not to renew your license, you 
can still use the product on your OpenCart installation, but you will no longer 
receive priority support for the product. It is strongly recommended that you 
renew the license to ensure that you have a professional support team available 
whenever you need it.

If you need any support for the product, send us a request at:
https://support.cuispi.com/



LICENSE
-------

See LICENSE.txt



COPYRIGHT
---------

(C) 2018 Cuispi


